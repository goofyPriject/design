package com.example.design.inventory;

public interface InventoryService {

    void dispatchingRequests(String type);

    void doSomething(String type);

}
